import json
import os
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from zoneinfo import ZoneInfo

from integrations.canvas.sync_calendar import run_sync


class CanvasCalendarSyncTests(unittest.TestCase):
    def setUp(self):
        self.sample = (Path(__file__).parent / "sample.ics").read_bytes()
        self.now = datetime(2026, 9, 5, 12, 0, tzinfo=ZoneInfo("America/Chicago"))

    def test_normalizes_assignment_and_event(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(
            os.environ,
            {
                "CANVAS_OUTPUT_DIR": tmp,
                "CANVAS_TIMEZONE": "America/Chicago",
                "CANVAS_UPCOMING_DAYS": "30",
                "CANVAS_COURSE_ALIASES_JSON": '{"12345":"ISYS-481"}',
            },
            clear=False,
        ):
            status = run_sync(ics_bytes=self.sample, now=self.now)
            data = json.loads((Path(tmp) / "calendar.json").read_text())

        self.assertEqual(status["record_count"], 2)
        assignment = next(item for item in data if item["event_type"] == "assignment")
        self.assertEqual(assignment["course"], "ISYS-481")
        self.assertEqual(assignment["assignment_id"], "5001")
        self.assertIn("due_at", assignment)
        self.assertNotIn("user_", json.dumps(data))

    def test_context_file_is_generated(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(
            os.environ,
            {
                "CANVAS_OUTPUT_DIR": tmp,
                "CANVAS_TIMEZONE": "America/Chicago",
                "CANVAS_UPCOMING_DAYS": "30",
                "CANVAS_COURSE_ALIASES_JSON": '{"12345":"ISYS-481"}',
            },
            clear=False,
        ):
            run_sync(ics_bytes=self.sample, now=self.now)
            context = (Path(tmp) / "ACADEMIC_CONTEXT.md").read_text()

        self.assertIn("ISYS-481", context)
        self.assertIn("Virtual Networks Lab", context)
        self.assertIn("Canvas To-Do items", context)

    def test_feed_secret_is_never_written(self):
        fake_secret = "https://maryville.instructure.com/feeds/calendars/user_SUPERSECRET.ics"
        with tempfile.TemporaryDirectory() as tmp, patch.dict(
            os.environ,
            {
                "CANVAS_OUTPUT_DIR": tmp,
                "CANVAS_TIMEZONE": "America/Chicago",
                "CANVAS_CALENDAR_FEED_URL": fake_secret,
            },
            clear=False,
        ):
            run_sync(ics_bytes=self.sample, now=self.now)
            combined = "\n".join(
                p.read_text() for p in Path(tmp).iterdir() if p.is_file()
            )

        self.assertNotIn(fake_secret, combined)
        self.assertNotIn("SUPERSECRET", combined)


if __name__ == "__main__":
    unittest.main()
